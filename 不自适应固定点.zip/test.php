[
  {
    "aqi": 58,
    "area": "淄博",
    "position_name": "人民公园",
    "primary_pollutant": "细颗粒物(PM2.5)",
    "quality": "良",
    "station_code": "1631A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 55,
    "area": "淄博",
    "position_name": "东风化工厂",
    "primary_pollutant": "颗粒物(PM10)",
    "quality": "良",
    "station_code": "1632A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 50,
    "area": "淄博",
    "position_name": "双山",
    "primary_pollutant": null,
    "quality": "优",
    "station_code": "1633A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 48,
    "area": "淄博",
    "position_name": "气象站",
    "primary_pollutant": null,
    "quality": "优",
    "station_code": "1634A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 35,
    "area": "淄博",
    "position_name": "莆田园",
    "primary_pollutant": null,
    "quality": "优",
    "station_code": "1635A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 31,
    "area": "淄博",
    "position_name": "三金集团",
    "primary_pollutant": null,
    "quality": "优",
    "station_code": "1636A",
    "time_point": "2020-03-31T12:00:00Z"
  },
  {
    "aqi": 46,
    "area": "淄博",
    "position_name": null,
    "primary_pollutant": "",
    "quality": "优",
    "station_code": null,
    "time_point": "2020-03-31T12:00:00Z"
  }
]